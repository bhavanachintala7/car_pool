CREATE DATABASE IF NOT EXISTS car_pooling_app;
USE car_pooling_app;

-- Drop tables if they already exist
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS rides;
DROP TABLE IF EXISTS vehicles;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS users;

SET FOREIGN_KEY_CHECKS = 1;

-- =========================
-- 1. USERS TABLE
-- =========================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('driver', 'passenger') NOT NULL,
    profile_image VARCHAR(255) DEFAULT 'https://via.placeholder.com/120',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- 2. ADMINS TABLE
-- =========================
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================
-- 3. VEHICLES TABLE
-- =========================
CREATE TABLE vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    vehicle_name VARCHAR(100) NOT NULL,
    vehicle_number VARCHAR(30) NOT NULL UNIQUE,
    color VARCHAR(50),
    seat_capacity INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =========================
-- 4. RIDES TABLE
-- =========================
CREATE TABLE rides (
    id INT AUTO_INCREMENT PRIMARY KEY,
    driver_id INT NOT NULL,
    vehicle_id INT NOT NULL,
    source VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    ride_date DATE NOT NULL,
    ride_time TIME NOT NULL,
    available_seats INT NOT NULL,
    price_per_seat DECIMAL(10,2) NOT NULL,
    notes TEXT,
    status ENUM('active', 'completed', 'cancelled') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (driver_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
);

-- =========================
-- 5. BOOKINGS TABLE
-- =========================
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ride_id INT NOT NULL,
    passenger_id INT NOT NULL,
    seats_booked INT NOT NULL DEFAULT 1,
    total_amount DECIMAL(10,2) NOT NULL,
    booking_status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'confirmed',
    message VARCHAR(255) DEFAULT 'Booking placed successfully',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
    FOREIGN KEY (passenger_id) REFERENCES users(id) ON DELETE CASCADE
);

-- =========================
-- 6. REVIEWS TABLE
-- =========================
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ride_id INT NOT NULL,
    from_user_id INT NOT NULL,
    to_user_id INT NOT NULL,
    rating INT NOT NULL,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ride_id) REFERENCES rides(id) ON DELETE CASCADE,
    FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE,
    CHECK (rating BETWEEN 1 AND 5)
);

-- =========================
-- 7. SAMPLE DATA
-- =========================

-- Password hash below is for: 123456
INSERT INTO admins (name, email, password)
VALUES
('Super Admin', 'admin@carpool.com', '$2b$10$wU9lApZhHFqRSbVSSMzdUOxQnt11sJ7Cl8r7XnV1TKoEt1TGVtC0i');

INSERT INTO users (full_name, email, phone, password, role)
VALUES
('Rahul Driver', 'rahul@example.com', '9876543210', '$2b$10$wU9lApZhHFqRSbVSSMzdUOxQnt11sJ7Cl8r7XnV1TKoEt1TGVtC0i', 'driver'),
('Anita Passenger', 'anita@example.com', '9876543211', '$2b$10$wU9lApZhHFqRSbVSSMzdUOxQnt11sJ7Cl8r7XnV1TKoEt1TGVtC0i', 'passenger');

INSERT INTO vehicles (user_id, vehicle_name, vehicle_number, color, seat_capacity)
VALUES
(1, 'Hyundai i20', 'TS09AB1234', 'White', 4);

INSERT INTO rides (driver_id, vehicle_id, source, destination, ride_date, ride_time, available_seats, price_per_seat, notes, status)
VALUES
(1, 1, 'Hyderabad', 'Gachibowli', '2026-03-20', '09:00:00', 3, 120.00, 'Office commute', 'active');

INSERT INTO bookings (ride_id, passenger_id, seats_booked, total_amount, booking_status, message)
VALUES
(1, 2, 1, 120.00, 'confirmed', 'Booking placed successfully');

INSERT INTO reviews (ride_id, from_user_id, to_user_id, rating, comment)
VALUES
(1, 2, 1, 5, 'Safe and comfortable ride');

-- =========================
-- 8. CHECK TABLES
-- =========================
SHOW TABLES;

SELECT * FROM admins;
SELECT * FROM users;
SELECT * FROM vehicles;
SELECT * FROM rides;
SELECT * FROM bookings;
SELECT * FROM reviews;
