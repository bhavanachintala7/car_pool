const db = require("../config/db");
const bcrypt = require("bcryptjs");
const generateToken = require("../utils/generateToken");

const registerUser = async (req, res) => {
  try {
    const { full_name, email, phone, password, role } = req.body;

    if (!full_name || !email || !phone || !password || !role) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const checkSql = "SELECT * FROM users WHERE email = ? OR phone = ?";
    db.query(checkSql, [email, phone], async (checkErr, checkResult) => {
      if (checkErr) {
        return res.status(500).json({ message: checkErr.message });
      }

      if (checkResult.length > 0) {
        return res.status(400).json({ message: "User already exists" });
      }

      const hashedPassword = await bcrypt.hash(password, 10);

      const sql =
        "INSERT INTO users (full_name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)";

      db.query(
        sql,
        [full_name, email, phone, hashedPassword, role],
        (err, result) => {
          if (err) {
            return res.status(500).json({ message: err.message });
          }

          const user = {
            id: result.insertId,
            email,
            role
          };

          res.status(201).json({
            message: "User registered successfully",
            token: generateToken(user),
            user: {
              id: result.insertId,
              full_name,
              email,
              phone,
              role
            }
          });
        }
      );
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const loginUser = (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" });
    }

    const sql = "SELECT * FROM users WHERE email = ?";

    db.query(sql, [email], async (err, result) => {
      if (err) {
        return res.status(500).json({ message: err.message });
      }

      if (result.length === 0) {
        return res.status(400).json({ message: "User not found" });
      }

      const user = result[0];
      const isMatch = await bcrypt.compare(password, user.password);

      if (!isMatch) {
        return res.status(400).json({ message: "Invalid password" });
      }

      const token = generateToken({
        id: user.id,
        email: user.email,
        role: user.role
      });

      res.json({
        message: "Login successful",
        token,
        user: {
          id: user.id,
          full_name: user.full_name,
          email: user.email,
          phone: user.phone,
          role: user.role
        }
      });
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  registerUser,
  loginUser
};