const db = require("../config/db");

const createRide = (req, res) => {
  try {
    const {
      vehicle_id,
      source,
      destination,
      ride_date,
      ride_time,
      available_seats,
      price_per_seat,
      notes
    } = req.body;

    const driver_id = req.user.id;

    if (
      !vehicle_id ||
      !source ||
      !destination ||
      !ride_date ||
      !ride_time ||
      !available_seats ||
      !price_per_seat
    ) {
      return res.status(400).json({ message: "All ride fields are required" });
    }

    const sql = `
      INSERT INTO rides
      (driver_id, vehicle_id, source, destination, ride_date, ride_time, available_seats, price_per_seat, notes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    db.query(
      sql,
      [
        driver_id,
        vehicle_id,
        source,
        destination,
        ride_date,
        ride_time,
        available_seats,
        price_per_seat,
        notes || ""
      ],
      (err, result) => {
        if (err) {
          return res.status(500).json({ message: err.message });
        }

        res.status(201).json({
          message: "Ride created successfully",
          rideId: result.insertId
        });
      }
    );
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const getAllRides = (req, res) => {
  try {
    const sql = `
      SELECT
        rides.*,
        users.full_name AS driver_name,
        vehicles.vehicle_name,
        vehicles.vehicle_number
      FROM rides
      JOIN users ON rides.driver_id = users.id
      JOIN vehicles ON rides.vehicle_id = vehicles.id
      ORDER BY rides.created_at DESC
    `;

    db.query(sql, (err, result) => {
      if (err) {
        return res.status(500).json({ message: err.message });
      }

      res.json(result);
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const searchRides = (req, res) => {
  try {
    const { source, destination, ride_date } = req.query;

    let sql = `
      SELECT
        rides.*,
        users.full_name AS driver_name,
        vehicles.vehicle_name,
        vehicles.vehicle_number
      FROM rides
      JOIN users ON rides.driver_id = users.id
      JOIN vehicles ON rides.vehicle_id = vehicles.id
      WHERE rides.status = 'active'
    `;

    const values = [];

    if (source) {
      sql += " AND rides.source LIKE ?";
      values.push(`%${source}%`);
    }

    if (destination) {
      sql += " AND rides.destination LIKE ?";
      values.push(`%${destination}%`);
    }

    if (ride_date) {
      sql += " AND rides.ride_date = ?";
      values.push(ride_date);
    }

    sql += " ORDER BY rides.ride_date ASC, rides.ride_time ASC";

    db.query(sql, values, (err, result) => {
      if (err) {
        return res.status(500).json({ message: err.message });
      }

      res.json(result);
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const getMyRides = (req, res) => {
  try {
    const driver_id = req.user.id;

    const sql = `
      SELECT *
      FROM rides
      WHERE driver_id = ?
      ORDER BY created_at DESC
    `;

    db.query(sql, [driver_id], (err, result) => {
      if (err) {
        return res.status(500).json({ message: err.message });
      }

      res.json(result);
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createRide,
  getAllRides,
  searchRides,
  getMyRides
};