const db = require("../config/db");

const bookRide = (req, res) => {
  try {
    const { ride_id, seats_booked } = req.body;
    const passenger_id = req.user.id;
    const seats = Number(seats_booked || 1);

    if (!ride_id) {
      return res.status(400).json({ message: "Ride ID is required" });
    }

    const getRideSql = "SELECT * FROM rides WHERE id = ?";

    db.query(getRideSql, [ride_id], (rideErr, rideResult) => {
      if (rideErr) {
        return res.status(500).json({ message: rideErr.message });
      }

      if (rideResult.length === 0) {
        return res.status(404).json({ message: "Ride not found" });
      }

      const ride = rideResult[0];

      if (ride.available_seats < seats) {
        return res.status(400).json({ message: "Not enough seats available" });
      }

      const total_amount = Number(ride.price_per_seat) * seats;

      const insertSql = `
        INSERT INTO bookings
        (ride_id, passenger_id, seats_booked, total_amount, booking_status, message)
        VALUES (?, ?, ?, ?, 'confirmed', 'Booking placed successfully')
      `;

      db.query(
        insertSql,
        [ride_id, passenger_id, seats, total_amount],
        (insertErr, insertResult) => {
          if (insertErr) {
            return res.status(500).json({ message: insertErr.message });
          }

          const updateRideSql =
            "UPDATE rides SET available_seats = available_seats - ? WHERE id = ?";

          db.query(updateRideSql, [seats, ride_id], (updateErr) => {
            if (updateErr) {
              return res.status(500).json({ message: updateErr.message });
            }

            res.status(201).json({
              message: "Ride booked successfully",
              bookingId: insertResult.insertId
            });
          });
        }
      );
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const getMyBookings = (req, res) => {
  try {
    const passenger_id = req.user.id;

    const sql = `
      SELECT
        bookings.*,
        rides.source,
        rides.destination,
        rides.ride_date,
        rides.ride_time,
        users.full_name AS driver_name
      FROM bookings
      JOIN rides ON bookings.ride_id = rides.id
      JOIN users ON rides.driver_id = users.id
      WHERE bookings.passenger_id = ?
      ORDER BY bookings.created_at DESC
    `;

    db.query(sql, [passenger_id], (err, result) => {
      if (err) {
        return res.status(500).json({ message: err.message });
      }

      res.json(result);
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

const cancelBooking = (req, res) => {
  try {
    const bookingId = req.params.id;

    const getBookingSql = "SELECT * FROM bookings WHERE id = ?";

    db.query(getBookingSql, [bookingId], (bookingErr, bookingResult) => {
      if (bookingErr) {
        return res.status(500).json({ message: bookingErr.message });
      }

      if (bookingResult.length === 0) {
        return res.status(404).json({ message: "Booking not found" });
      }

      const booking = bookingResult[0];

      if (booking.booking_status === "cancelled") {
        return res.status(400).json({ message: "Booking already cancelled" });
      }

      const updateBookingSql =
        "UPDATE bookings SET booking_status = 'cancelled', message = 'Booking cancelled' WHERE id = ?";

      db.query(updateBookingSql, [bookingId], (updateBookingErr) => {
        if (updateBookingErr) {
          return res.status(500).json({ message: updateBookingErr.message });
        }

        const updateRideSql =
          "UPDATE rides SET available_seats = available_seats + ? WHERE id = ?";

        db.query(
          updateRideSql,
          [booking.seats_booked, booking.ride_id],
          (updateRideErr) => {
            if (updateRideErr) {
              return res.status(500).json({ message: updateRideErr.message });
            }

            res.json({ message: "Booking cancelled successfully" });
          }
        );
      });
    });
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

module.exports = {
  bookRide,
  getMyBookings,
  cancelBooking
};