const express = require("express");
const router = express.Router();
const protect = require("../middleware/authMiddleware");
const {
  createRide,
  getAllRides,
  searchRides,
  getMyRides
} = require("../controllers/rideController");

router.get("/", getAllRides);
router.get("/search", searchRides);
router.get("/my", protect, getMyRides);
router.post("/", protect, createRide);

module.exports = router;