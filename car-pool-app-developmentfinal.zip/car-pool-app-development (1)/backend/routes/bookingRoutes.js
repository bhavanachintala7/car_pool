const express = require("express");
const router = express.Router();
const protect = require("../middleware/authMiddleware");
const {
  bookRide,
  getMyBookings,
  cancelBooking
} = require("../controllers/bookingController");

router.post("/", protect, bookRide);
router.get("/my", protect, getMyBookings);
router.put("/:id/cancel", protect, cancelBooking);

module.exports = router;