import { useState, useEffect } from 'react';
import { Car, Users, MapPin, Calendar, Clock, User, LogOut, Plus, Search, Bell, Star, Edit2, Trash2 } from 'lucide-react';
import { cn } from './utils/cn';

interface User {
  id: number;
  name: string;
  email: string;
  role: 'driver' | 'passenger' | 'admin';
  bio?: string;
  avatar: string;
  rating?: number;
}

interface Vehicle {
  id: number;
  model: string;
  plate: string;
  seats: number;
}

interface Ride {
  id: number;
  driverId: number;
  driverName: string;
  from: string;
  to: string;
  date: string;
  time: string;
  seatsAvailable: number;
  pricePerSeat: number;
  vehicleModel: string;
  status: 'active' | 'completed' | 'cancelled';
}

interface Booking {
  id: number;
  rideId: number;
  passengerId: number;
  passengerName: string;
  seatsBooked: number;
  totalPrice: number;
  status: 'confirmed' | 'cancelled';
  ride?: Ride;
}

interface Notification {
  id: number;
  message: string;
  time: string;
  read: boolean;
}

const mockUsers: User[] = [
  { id: 1, name: "Alex Rivera", email: "alex@driver.com", role: "driver", bio: "Experienced driver, love sharing rides", avatar: "https://i.pravatar.cc/150?u=alex", rating: 4.8 },
  { id: 2, name: "Sam Chen", email: "sam@passenger.com", role: "passenger", bio: "Frequent traveler", avatar: "https://i.pravatar.cc/150?u=sam", rating: 4.5 },
  { id: 3, name: "Admin User", email: "admin@ridesync.com", role: "admin", avatar: "https://i.pravatar.cc/150?u=admin", rating: 5.0 },
];

const initialRides: Ride[] = [
  {
    id: 1,
    driverId: 1,
    driverName: "Alex Rivera",
    from: "San Francisco",
    to: "Los Angeles",
    date: "2024-12-15",
    time: "09:00",
    seatsAvailable: 3,
    pricePerSeat: 45,
    vehicleModel: "Tesla Model 3",
    status: "active"
  },
  {
    id: 2,
    driverId: 1,
    driverName: "Alex Rivera",
    from: "San Francisco",
    to: "Sacramento",
    date: "2024-12-16",
    time: "14:30",
    seatsAvailable: 2,
    pricePerSeat: 25,
    vehicleModel: "Honda Civic",
    status: "active"
  },
  {
    id: 3,
    driverId: 4,
    driverName: "Jordan Kim",
    from: "New York",
    to: "Boston",
    date: "2024-12-17",
    time: "08:00",
    seatsAvailable: 4,
    pricePerSeat: 35,
    vehicleModel: "Toyota Camry",
    status: "active"
  }
];

const initialBookings: Booking[] = [
  {
    id: 101,
    rideId: 1,
    passengerId: 2,
    passengerName: "Sam Chen",
    seatsBooked: 1,
    totalPrice: 45,
    status: "confirmed",
  }
];

const initialNotifications: Notification[] = [
  { id: 1, message: "Your booking for SF to LA has been confirmed!", time: "2h ago", read: false },
  { id: 2, message: "Alex Rivera accepted your ride request", time: "5h ago", read: true },
];

export function App() {
  // State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [currentPage, setCurrentPage] = useState<'login' | 'signup' | 'dashboard' | 'search' | 'post-ride' | 'my-rides' | 'profile' | 'admin'>('login');
  const [rides, setRides] = useState<Ride[]>(initialRides);
  const [bookings, setBookings] = useState<Booking[]>(initialBookings);
  const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
  const [showNotifications, setShowNotifications] = useState(false);
  const [searchFilters, setSearchFilters] = useState({
    from: '',
    to: '',
    date: '',
  });
  const [filteredRides, setFilteredRides] = useState<Ride[]>([]);
  const [selectedRide, setSelectedRide] = useState<Ride | null>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [bookingSeats, setBookingSeats] = useState(1);
  const [newRide, setNewRide] = useState({
    from: '',
    to: '',
    date: '',
    time: '',
    seatsAvailable: 3,
    pricePerSeat: 30,
    vehicleModel: 'Toyota Camry',
  });
  const [profileEdit, setProfileEdit] = useState(false);
  const [editedUser, setEditedUser] = useState<User | null>(null);
  const [userVehicle] = useState<Vehicle>({
    id: 1,
    model: "Tesla Model Y",
    plate: "CAL-7K9P",
    seats: 4,
  });
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewRide, setReviewRide] = useState<Ride | null>(null);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');

  // Login as demo users
  const demoLogin = (role: 'driver' | 'passenger' | 'admin') => {
    const user = mockUsers.find(u => u.role === role) || mockUsers[0];
    setCurrentUser(user);
    setCurrentPage('dashboard');
    // Add some more mock bookings for passenger
    if (role === 'passenger') {
      setBookings([...initialBookings, {
        id: 102,
        rideId: 2,
        passengerId: 2,
        passengerName: "Sam Chen",
        seatsBooked: 2,
        totalPrice: 50,
        status: "confirmed",
      }]);
    }
  };

  const handleLogin = (email: string) => {
    // Mock login
    let user = mockUsers.find(u => u.email === email);
    if (!user) {
      user = mockUsers[0]; // default to first
    }
    setCurrentUser(user);
    setCurrentPage('dashboard');
  };

  const handleSignup = (name: string, email: string, role: 'driver' | 'passenger') => {
    const newUser: User = {
      id: Date.now(),
      name,
      email,
      role,
      bio: "New user on RideSync",
      avatar: `https://i.pravatar.cc/150?u=${Date.now()}`,
      rating: 4.0
    };
    setCurrentUser(newUser);
    setCurrentPage('dashboard');
  };

  const logout = () => {
    setCurrentUser(null);
    setCurrentPage('login');
    setNotifications(initialNotifications);
  };

  // Search rides
  const searchRides = () => {
    let results = [...rides].filter(r => r.status === 'active');
    
    if (searchFilters.from) {
      results = results.filter(r => 
        r.from.toLowerCase().includes(searchFilters.from.toLowerCase())
      );
    }
    if (searchFilters.to) {
      results = results.filter(r => 
        r.to.toLowerCase().includes(searchFilters.to.toLowerCase())
      );
    }
    if (searchFilters.date) {
      results = results.filter(r => r.date === searchFilters.date);
    }
    
    setFilteredRides(results);
    setCurrentPage('search');
  };

  const bookRide = (ride: Ride) => {
    if (!currentUser) return;
    
    if (ride.seatsAvailable < bookingSeats) {
      alert("Not enough seats available!");
      return;
    }
    
    const newBooking: Booking = {
      id: Date.now(),
      rideId: ride.id,
      passengerId: currentUser.id,
      passengerName: currentUser.name,
      seatsBooked: bookingSeats,
      totalPrice: ride.pricePerSeat * bookingSeats,
      status: 'confirmed',
      ride: ride
    };
    
    setBookings(prev => [...prev, newBooking]);
    
    // Update ride seats
    setRides(prev => prev.map(r => 
      r.id === ride.id 
        ? { ...r, seatsAvailable: r.seatsAvailable - bookingSeats } 
        : r
    ));
    
    setShowBookingModal(false);
    setBookingSeats(1);
    alert(`Successfully booked ${bookingSeats} seat(s) for $${newBooking.totalPrice}!`);
    
    // Add notification
    setNotifications(prev => [{
      id: Date.now(),
      message: `Booking confirmed for ${ride.from} to ${ride.to}`,
      time: "Just now",
      read: false
    }, ...prev]);
  };

  const cancelBooking = (bookingId: number) => {
    if (!confirm("Cancel this booking?")) return;
    
    setBookings(prev => prev.map(b => 
      b.id === bookingId ? { ...b, status: 'cancelled' } : b
    ));
    
    // In real app would update ride seats back
    alert("Booking cancelled successfully.");
  };

  const postNewRide = () => {
    if (!currentUser || currentUser.role !== 'driver') return;
    
    const ride: Ride = {
      id: Date.now(),
      driverId: currentUser.id,
      driverName: currentUser.name,
      from: newRide.from,
      to: newRide.to,
      date: newRide.date,
      time: newRide.time,
      seatsAvailable: newRide.seatsAvailable,
      pricePerSeat: newRide.pricePerSeat,
      vehicleModel: newRide.vehicleModel,
      status: 'active'
    };
    
    setRides(prev => [ride, ...prev]);
    setNewRide({
      from: '',
      to: '',
      date: '',
      time: '',
      seatsAvailable: 3,
      pricePerSeat: 30,
      vehicleModel: 'Toyota Camry',
    });
    
    alert("Ride posted successfully!");
    setCurrentPage('my-rides');
  };

  const completeRide = (rideId: number) => {
    setRides(prev => prev.map(r => 
      r.id === rideId ? { ...r, status: 'completed' } : r
    ));
    setShowReviewModal(true);
    const ride = rides.find(r => r.id === rideId);
    setReviewRide(ride || null);
  };

  const submitReview = () => {
    if (!reviewRide || !currentUser) return;
    
    alert(`Thank you for your ${reviewRating} star review! "${reviewComment}"`);
    setShowReviewModal(false);
    setReviewComment('');
    setReviewRating(5);
  };

  const deleteRide = (rideId: number) => {
    if (!confirm('Delete this ride?')) return;
    setRides(prev => prev.filter(r => r.id !== rideId));
  };

  // Filter my rides/bookings
  const myRides = currentUser ? rides.filter(r => r.driverId === currentUser.id) : [];
  const myBookings = currentUser && currentUser.role === 'passenger' 
    ? bookings.filter(b => b.passengerId === currentUser.id) 
    : [];

  // Fake admin users and rides
  const allUsers = mockUsers;
  const allRidesForAdmin = rides;

  useEffect(() => {
    if (currentPage === 'search' && searchFilters.from === '' && searchFilters.to === '') {
      setFilteredRides(rides.filter(r => r.status === 'active'));
    }
  }, [currentPage, rides]);

  if (!currentUser && currentPage !== 'signup') {
    return (
      <div className="min-h-screen bg-zinc-950 text-white">
        <div className="flex min-h-screen items-center justify-center p-6">
          <div className="w-full max-w-md">
            {/* Login Screen */}
            <div className="flex flex-col items-center mb-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="h-12 w-12 bg-emerald-500 rounded-2xl flex items-center justify-center">
                  <Car className="h-7 w-7 text-white" />
                </div>
                <div>
                  <h1 className="text-4xl font-bold tracking-tighter">RideSync</h1>
                  <p className="text-emerald-400 text-sm -mt-1">carpool together</p>
                </div>
              </div>
              <p className="text-zinc-400 text-center max-w-xs">Connect with drivers and passengers heading the same way</p>
            </div>

            <div className="bg-zinc-900 rounded-3xl p-8 shadow-2xl border border-zinc-800">
              <h2 className="text-2xl font-semibold mb-6 text-center">Welcome back</h2>
              
              <div className="space-y-4 mb-8">
                <button 
                  onClick={() => demoLogin('driver')}
                  className="w-full py-3.5 bg-white text-zinc-900 hover:bg-zinc-100 transition rounded-2xl font-medium flex items-center justify-center gap-2"
                >
                  <Car className="h-5 w-5" />
                  Login as Driver
                </button>
                
                <button 
                  onClick={() => demoLogin('passenger')}
                  className="w-full py-3.5 bg-white text-zinc-900 hover:bg-zinc-100 transition rounded-2xl font-medium flex items-center justify-center gap-2"
                >
                  <Users className="h-5 w-5" />
                  Login as Passenger
                </button>
                
                <button 
                  onClick={() => demoLogin('admin')}
                  className="w-full py-3.5 bg-amber-500 hover:bg-amber-600 transition text-white rounded-2xl font-medium flex items-center justify-center gap-2"
                >
                  <User className="h-5 w-5" />
                  Login as Admin
                </button>
              </div>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-zinc-800"></div>
                </div>
                <div className="relative flex justify-center text-xs uppercase tracking-widest text-zinc-500">or</div>
              </div>

              <form onSubmit={(e) => { e.preventDefault(); const form = e.target as HTMLFormElement; handleLogin((form.email as any).value); }} className="space-y-4">
                <div>
                  <label className="text-xs text-zinc-400 block mb-1.5">EMAIL ADDRESS</label>
                  <input 
                    type="email" 
                    name="email"
                    defaultValue="alex@driver.com"
                    className="w-full bg-zinc-800 border border-zinc-700 focus:border-emerald-500 rounded-2xl px-4 py-3 outline-none text-sm"
                    placeholder="you@email.com"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs text-zinc-400 block mb-1.5">PASSWORD</label>
                  <input 
                    type="password" 
                    name="password"
                    defaultValue="demo123"
                    className="w-full bg-zinc-800 border border-zinc-700 focus:border-emerald-500 rounded-2xl px-4 py-3 outline-none text-sm"
                    required
                  />
                </div>
                
                <button type="submit" className="mt-2 w-full bg-emerald-600 hover:bg-emerald-500 py-3.5 rounded-2xl font-semibold transition">
                  Sign in
                </button>
              </form>

              <div className="text-center mt-6">
                <button 
                  onClick={() => setCurrentPage('signup')}
                  className="text-emerald-400 hover:text-emerald-300 text-sm font-medium"
                >
                  Don't have an account? Sign up
                </button>
              </div>
            </div>
            
            <div className="text-center text-[10px] text-zinc-500 mt-8">
              Demo for hackathon presentation • All data is in-memory
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (currentPage === 'signup') {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-6 text-white">
        <div className="max-w-md w-full bg-zinc-900 rounded-3xl p-8">
          <div className="flex items-center gap-3 mb-8">
            <div className="h-9 w-9 bg-emerald-500 rounded-xl flex items-center justify-center">
              <Car className="h-5 w-5" />
            </div>
            <h1 className="font-bold text-3xl tracking-tighter">RideSync</h1>
          </div>
          
          <h2 className="text-3xl font-semibold mb-2">Create account</h2>
          <p className="text-zinc-400 mb-8">Join thousands sharing rides daily</p>
          
          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const name = formData.get('name') as string;
            const email = formData.get('email') as string;
            const role = formData.get('role') as 'driver' | 'passenger';
            handleSignup(name, email, role);
          }} className="space-y-5">
            <div>
              <label className="block text-xs tracking-widest text-zinc-400 mb-2">FULL NAME</label>
              <input name="name" type="text" className="w-full px-5 py-3.5 bg-zinc-800 border border-zinc-700 rounded-2xl text-white" placeholder="Taylor Kim" required />
            </div>
            
            <div>
              <label className="block text-xs tracking-widest text-zinc-400 mb-2">EMAIL</label>
              <input name="email" type="email" className="w-full px-5 py-3.5 bg-zinc-800 border border-zinc-700 rounded-2xl text-white" placeholder="taylor@example.com" required />
            </div>
            
            <div>
              <label className="block text-xs tracking-widest text-zinc-400 mb-2">I AM A</label>
              <div className="grid grid-cols-2 gap-4">
                <label className="cursor-pointer">
                  <input type="radio" name="role" value="driver" defaultChecked className="peer sr-only" />
                  <div className="peer-checked:bg-emerald-500 peer-checked:text-white border border-zinc-700 hover:border-zinc-600 transition bg-zinc-800 px-5 py-4 rounded-2xl text-center">Driver</div>
                </label>
                <label className="cursor-pointer">
                  <input type="radio" name="role" value="passenger" className="peer sr-only" />
                  <div className="peer-checked:bg-emerald-500 peer-checked:text-white border border-zinc-700 hover:border-zinc-600 transition bg-zinc-800 px-5 py-4 rounded-2xl text-center">Passenger</div>
                </label>
              </div>
            </div>
            
            <button type="submit" className="w-full bg-white text-black py-4 rounded-2xl font-semibold mt-2">Create my account</button>
          </form>
          
          <button onClick={() => setCurrentPage('login')} className="mt-6 text-sm text-zinc-400 hover:text-white w-full">Already have an account? Log in</button>
        </div>
      </div>
    );
  }

  // Main App
  return (
    <div className="min-h-screen bg-zinc-950 text-white">
      {/* NAVBAR */}
      <nav className="bg-zinc-900 border-b border-zinc-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-x-16">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 bg-emerald-500 text-black rounded-2xl flex items-center justify-center">
                <Car className="h-5 w-5" />
              </div>
              <div className="font-semibold tracking-tighter text-2xl">RideSync</div>
            </div>

            <div className="hidden md:flex items-center gap-x-8 text-sm font-medium">
              <button 
                onClick={() => setCurrentPage('dashboard')}
                className={cn("transition hover:text-white", currentPage === 'dashboard' ? "text-white" : "text-zinc-400")}
              >
                Dashboard
              </button>
              <button 
                onClick={() => { setCurrentPage('search'); searchRides(); }}
                className={cn("transition hover:text-white", currentPage === 'search' ? "text-white" : "text-zinc-400")}
              >
                Find Rides
              </button>
              
              {currentUser?.role === 'driver' && (
                <button 
                  onClick={() => setCurrentPage('post-ride')}
                  className={cn("transition hover:text-white", currentPage === 'post-ride' ? "text-white" : "text-zinc-400")}
                >
                  Post a Ride
                </button>
              )}
              
              <button 
                onClick={() => setCurrentPage('my-rides')}
                className={cn("transition hover:text-white", currentPage === 'my-rides' ? "text-white" : "text-zinc-400")}
              >
                My Trips
              </button>
            </div>
          </div>

          <div className="flex items-center gap-x-6">
            {/* Notifications */}
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="h-9 w-9 flex items-center justify-center hover:bg-zinc-800 rounded-xl transition relative"
              >
                <Bell className="h-5 w-5" />
                {notifications.filter(n => !n.read).length > 0 && (
                  <div className="absolute top-1 right-1 h-4 w-4 bg-red-500 rounded-full flex items-center justify-center text-[9px] font-bold">3</div>
                )}
              </button>
              
              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-zinc-900 border border-zinc-700 rounded-3xl shadow-2xl overflow-hidden z-50 py-2">
                  <div className="px-5 py-3 border-b border-zinc-800 font-medium text-sm">Notifications</div>
                  {notifications.length === 0 ? (
                    <div className="px-5 py-8 text-center text-zinc-400 text-sm">No notifications</div>
                  ) : (
                    notifications.map((notif, index) => (
                      <div key={index} className="px-5 py-3.5 hover:bg-zinc-800 border-b border-zinc-800 last:border-none text-sm">
                        <div>{notif.message}</div>
                        <div className="text-[10px] text-zinc-500 mt-1">{notif.time}</div>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>

            <div className="flex items-center gap-x-3 pr-3">
              <div className="text-right">
                <div className="text-sm font-medium leading-none">{currentUser.name}</div>
                <div className="text-[10px] text-emerald-400 font-mono tracking-widest uppercase">{currentUser.role}</div>
              </div>
              <div className="h-9 w-9 rounded-2xl overflow-hidden border border-zinc-700">
                <img src={currentUser.avatar} alt={currentUser.name} className="h-full w-full object-cover" />
              </div>
              <button onClick={logout} className="ml-2 text-zinc-400 hover:text-red-400">
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <div className="flex max-w-7xl mx-auto">
        {/* SIDEBAR */}
        <div className="w-60 hidden lg:block border-r border-zinc-800 h-[calc(100vh-64px)] py-8 px-5 bg-zinc-900">
          <div className="uppercase text-xs tracking-[0.5px] font-mono text-zinc-500 mb-4 px-3">MENU</div>
          
          <div className="space-y-1">
            {[
              { label: 'Dashboard', icon: <Car className="h-4 w-4" />, page: 'dashboard' as const},
              { label: 'Find rides', icon: <Search className="h-4 w-4" />, page: 'search' as const},
              currentUser.role === 'driver' && { label: 'Offer a ride', icon: <Plus className="h-4 w-4" />, page: 'post-ride' as const},
              { label: 'My trips', icon: <MapPin className="h-4 w-4" />, page: 'my-rides' as const},
              { label: 'Profile', icon: <User className="h-4 w-4" />, page: 'profile' as const},
            ].filter(Boolean).map((item: any) => (
              <button
                key={item.page}
                onClick={() => {
                  setCurrentPage(item.page);
                  if (item.page === 'search') searchRides();
                }}
                className={cn(
                  "flex w-full items-center gap-3 px-4 py-3 text-sm rounded-2xl transition",
                  currentPage === item.page 
                    ? "bg-white bg-opacity-10 text-white" 
                    : "hover:bg-white/5 text-zinc-400"
                )}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </div>

          {currentUser.role === 'admin' && (
            <button 
              onClick={() => setCurrentPage('admin')}
              className={cn(
                "mt-8 flex w-full items-center gap-3 px-4 py-3 text-sm rounded-2xl transition",
                currentPage === 'admin' ? "bg-white bg-opacity-10 text-white" : "hover:bg-white/5 text-amber-400"
              )}
            >
              <Edit2 className="h-4 w-4" /> Admin Panel
            </button>
          )}

          <div className="absolute bottom-8 px-4 text-[10px] text-zinc-500">
            Built as a hackathon demo<br />using React + Tailwind
          </div>
        </div>

        {/* MAIN CONTENT */}
        <div className="flex-1 p-6 lg:p-10 overflow-auto" style={{height: 'calc(100vh - 64px)'}}>
          {/* DASHBOARD */}
          {currentPage === 'dashboard' && (
            <div>
              <div className="flex justify-between items-end mb-8">
                <div>
                  <div className="uppercase text-emerald-400 text-xs tracking-widest">WELCOME BACK</div>
                  <h1 className="text-5xl font-semibold tracking-tighter">Good morning, {currentUser.name.split(' ')[0]}</h1>
                </div>
                
                <div className="flex gap-3">
                  <div onClick={() => setCurrentPage('search')} className="bg-zinc-900 hover:bg-zinc-800 transition border border-zinc-700 px-6 py-3 rounded-3xl flex items-center gap-2 cursor-pointer">
                    <Search className="h-4 w-4" /> Find rides
                  </div>
                  {currentUser.role === 'driver' && (
                    <div onClick={() => setCurrentPage('post-ride')} className="bg-emerald-600 hover:bg-emerald-500 transition px-6 py-3 rounded-3xl flex items-center gap-2 cursor-pointer">
                      <Plus className="h-4 w-4" /> Post ride
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                {/* Stats */}
                <div className="md:col-span-7 bg-zinc-900 rounded-3xl p-8">
                  <h3 className="font-medium mb-6 flex items-center gap-2">
                    <span className="text-emerald-400">📍</span> YOUR ACTIVITY
                  </h3>
                  
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-zinc-950 rounded-2xl p-6">
                      <div className="text-emerald-400 text-xs font-mono mb-1">RIDES TAKEN</div>
                      <div className="text-6xl font-semibold tabular-nums tracking-tighter text-white">12</div>
                      <div className="text-xs text-zinc-400 mt-6">this month</div>
                    </div>
                    <div className="bg-zinc-950 rounded-2xl p-6">
                      <div className="text-emerald-400 text-xs font-mono mb-1">MILES SAVED</div>
                      <div className="text-6xl font-semibold tabular-nums tracking-tighter text-white">184</div>
                      <div className="text-xs text-zinc-400 mt-6">CO₂ reduced</div>
                    </div>
                    <div className="bg-zinc-950 rounded-2xl p-6">
                      <div className="text-emerald-400 text-xs font-mono mb-1">AVG RATING</div>
                      <div className="text-6xl font-semibold tabular-nums tracking-tighter text-white flex items-baseline gap-1">4.9 <Star className="h-6 w-6 fill-yellow-300 text-yellow-300" /></div>
                      <div className="text-xs text-zinc-400 mt-6">from 31 reviews</div>
                    </div>
                  </div>
                </div>

                {/* Next trip */}
                <div className="md:col-span-5 bg-zinc-900 rounded-3xl p-8 flex flex-col">
                  <div className="flex-1">
                    <div className="uppercase text-xs text-zinc-400">YOUR NEXT TRIP</div>
                    {myBookings.length > 0 ? (
                      <div className="mt-6">
                        <div className="font-semibold text-xl">{myBookings[0].ride?.from} → {myBookings[0].ride?.to}</div>
                        <div className="flex items-center gap-4 text-sm mt-6 text-zinc-400">
                          <div className="flex items-center gap-1.5"><Calendar className="h-4 w-4" /> {myBookings[0].ride?.date}</div>
                          <div className="flex items-center gap-1.5"><Clock className="h-4 w-4" /> {myBookings[0].ride?.time}</div>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-12 text-center text-zinc-400">No upcoming trips.<br />Book a ride today.</div>
                    )}
                  </div>
                  <button onClick={() => setCurrentPage('search')} className="mt-auto border border-white/30 hover:bg-white/5 py-3.5 rounded-2xl text-sm">Browse available rides →</button>
                </div>

                {/* Recent activity */}
                <div className="md:col-span-12 mt-2">
                  <h2 className="font-medium text-lg mb-5 flex items-center justify-between">
                    Recent Activity 
                    <button onClick={() => setCurrentPage('my-rides')} className="text-xs text-emerald-400 hover:underline">View all history →</button>
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {bookings.slice(0, 2).map((booking, idx) => {
                      const rideInfo = rides.find(r => r.id === booking.rideId);
                      return (
                        <div key={idx} className="bg-zinc-900 rounded-3xl p-6 flex gap-6">
                          <div className="h-11 w-11 bg-zinc-800 rounded-2xl flex-none flex items-center justify-center text-2xl">🚗</div>
                          <div className="flex-1 min-w-0">
                            <div className="font-medium">{rideInfo?.from} to {rideInfo?.to}</div>
                            <div className="text-xs text-zinc-400 mt-px">{rideInfo?.date} • {booking.seatsBooked} seat{booking.seatsBooked > 1 ? 's' : ''}</div>
                            
                            <div className="flex items-center justify-between mt-5">
                              <div className={`inline text-xs px-3 py-1 rounded-full ${booking.status === 'confirmed' ? 'bg-emerald-900 text-emerald-400' : 'bg-red-900 text-red-400'}`}>
                                {booking.status.toUpperCase()}
                              </div>
                              <div className="text-xs text-right text-zinc-400">Total ${booking.totalPrice}</div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SEARCH RIDES */}
          {currentPage === 'search' && (
            <div>
              <div className="max-w-2xl mx-auto mb-10">
                <h1 className="text-4xl font-semibold tracking-tight mb-2">Find your next ride</h1>
                <p className="text-zinc-400">Search for available carpools in your route</p>
              </div>

              {/* Search Form */}
              <div className="bg-zinc-900 rounded-3xl p-8 mb-10 max-w-2xl mx-auto">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  <div>
                    <label className="text-xs font-medium text-zinc-400 block mb-2">FROM</label>
                    <input 
                      type="text" 
                      value={searchFilters.from}
                      onChange={(e) => setSearchFilters({...searchFilters, from: e.target.value})}
                      className="bg-zinc-800 w-full border border-transparent focus:border-emerald-500 rounded-2xl px-5 py-4 text-lg placeholder:text-zinc-500"
                      placeholder="San Francisco"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-zinc-400 block mb-2">TO</label>
                    <input 
                      type="text" 
                      value={searchFilters.to}
                      onChange={(e) => setSearchFilters({...searchFilters, to: e.target.value})}
                      className="bg-zinc-800 w-full border border-transparent focus:border-emerald-500 rounded-2xl px-5 py-4 text-lg placeholder:text-zinc-500"
                      placeholder="Los Angeles"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-zinc-400 block mb-2">DATE</label>
                    <input 
                      type="date" 
                      value={searchFilters.date}
                      onChange={(e) => setSearchFilters({...searchFilters, date: e.target.value})}
                      className="bg-zinc-800 w-full border border-transparent focus:border-emerald-500 rounded-2xl px-5 py-4 text-lg placeholder:text-zinc-500"
                    />
                  </div>
                </div>
                <button 
                  onClick={searchRides}
                  className="mt-6 w-full bg-white text-zinc-950 py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 hover:scale-[1.015] active:scale-[0.985] transition-all"
                >
                  <Search className="h-5 w-5" /> SEARCH AVAILABLE RIDES
                </button>
              </div>

              {/* Results */}
              <div className="mt-8">
                <div className="flex justify-between items-baseline mb-6">
                  <div className="text-xl font-medium">Available rides {filteredRides.length > 0 && `(${filteredRides.length})`}</div>
                  <div className="text-xs text-zinc-400">SORT BY PRICE</div>
                </div>

                {filteredRides.length === 0 ? (
                  <div className="bg-zinc-900 rounded-3xl py-20 text-center">
                    <div className="mx-auto w-16 h-16 bg-zinc-800 rounded-full flex items-center justify-center mb-6">🔎</div>
                    <div className="font-medium">No rides found</div>
                    <div className="text-zinc-400 text-sm mt-3 max-w-xs mx-auto">Try changing your search criteria or check back later.</div>
                  </div>
                ) : (
                  <div className="space-y-5">
                    {filteredRides.map(ride => (
                      <div key={ride.id} className="bg-zinc-900 rounded-3xl p-7 flex flex-col md:flex-row md:items-center gap-8 hover:border-emerald-900 border border-transparent transition group">
                        <div className="flex-1">
                          <div className="flex items-center gap-4">
                            <div>
                              <div className="font-mono text-xs text-emerald-400">DEPARTURE</div>
                              <div className="text-4xl font-semibold tabular-nums tracking-tighter">{ride.time}</div>
                            </div>
                            
                            <div className="h-px flex-1 bg-gradient-to-r from-emerald-400/30 via-zinc-700 to-transparent mt-6"></div>
                            
                            <div className="text-right">
                              <div className="font-semibold text-xl">{ride.from}</div>
                              <div className="text-xs text-zinc-400">to</div>
                              <div className="font-semibold text-xl">{ride.to}</div>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-2 mt-6 text-xs">
                            <div className="bg-zinc-800 text-zinc-400 px-4 py-1 rounded-3xl flex items-center gap-2">
                              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                              {ride.driverName}
                            </div>
                            <div className="bg-zinc-800 px-3 py-1 rounded-3xl">{ride.vehicleModel}</div>
                          </div>
                        </div>
                        
                        <div className="flex flex-col items-end justify-between md:text-right gap-y-3">
                          <div>
                            <div className="text-xs text-zinc-400">PER SEAT</div>
                            <div className="text-5xl font-semibold text-emerald-300 tabular-nums tracking-tighter">${ride.pricePerSeat}</div>
                          </div>
                          
                          <div className="text-xs flex items-center gap-1 text-zinc-400">
                            <Users className="h-3.5 w-3.5" /> {ride.seatsAvailable} left
                          </div>
                          
                          <button 
                            onClick={() => {
                              setSelectedRide(ride);
                              setShowBookingModal(true);
                              setBookingSeats(Math.min(2, ride.seatsAvailable));
                            }}
                            className="mt-2 bg-white hover:bg-emerald-400 hover:text-zinc-950 transition-all text-black font-semibold px-10 py-3 rounded-2xl text-sm"
                          >
                            BOOK NOW
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* POST RIDE */}
          {currentPage === 'post-ride' && currentUser?.role === 'driver' && (
            <div className="max-w-lg mx-auto">
              <h1 className="text-4xl font-semibold mb-2 tracking-tight">Offer a new ride</h1>
              <p className="text-zinc-400 mb-8">Share your journey and earn money</p>
              
              <div className="bg-zinc-900 rounded-3xl p-9">
                <div className="space-y-8">
                  <div className="grid grid-cols-2 gap-5">
                    <div>
                      <label className="text-xs text-zinc-400">DEPARTURE CITY</label>
                      <input 
                        value={newRide.from} 
                        onChange={(e) => setNewRide({...newRide, from: e.target.value})}
                        className="mt-2 block w-full bg-transparent border-b border-zinc-700 pb-3 text-xl focus:outline-none" 
                        placeholder="San Francisco" 
                      />
                    </div>
                    <div>
                      <label className="text-xs text-zinc-400">DESTINATION CITY</label>
                      <input 
                        value={newRide.to} 
                        onChange={(e) => setNewRide({...newRide, to: e.target.value})}
                        className="mt-2 block w-full bg-transparent border-b border-zinc-700 pb-3 text-xl focus:outline-none" 
                        placeholder="Los Angeles" 
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-5">
                    <div>
                      <label className="text-xs text-zinc-400">DATE</label>
                      <input 
                        type="date"
                        value={newRide.date} 
                        onChange={(e) => setNewRide({...newRide, date: e.target.value})}
                        className="mt-2 block w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-5 py-4" 
                      />
                    </div>
                    <div>
                      <label className="text-xs text-zinc-400">TIME</label>
                      <input 
                        type="time"
                        value={newRide.time} 
                        onChange={(e) => setNewRide({...newRide, time: e.target.value})}
                        className="mt-2 block w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-5 py-4" 
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-5">
                    <div>
                      <label className="text-xs text-zinc-400">SEATS</label>
                      <input 
                        type="number" 
                        min="1" 
                        max="6"
                        value={newRide.seatsAvailable} 
                        onChange={(e) => setNewRide({...newRide, seatsAvailable: parseInt(e.target.value) || 1})}
                        className="mt-2 block w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-5 py-4 text-center text-2xl font-semibold" 
                      />
                    </div>
                    <div>
                      <label className="text-xs text-zinc-400">PRICE/SEAT</label>
                      <div className="mt-2 relative">
                        <div className="absolute left-5 top-4 text-zinc-400">$</div>
                        <input 
                          type="number" 
                          value={newRide.pricePerSeat} 
                          onChange={(e) => setNewRide({...newRide, pricePerSeat: parseInt(e.target.value) || 0})}
                          className="block w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-8 py-4 text-2xl font-semibold" 
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-xs text-zinc-400">VEHICLE</label>
                      <input 
                        value={newRide.vehicleModel} 
                        onChange={(e) => setNewRide({...newRide, vehicleModel: e.target.value})}
                        className="mt-2 block w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-5 py-4" 
                        placeholder="Car model"
                      />
                    </div>
                  </div>
                </div>
                
                <button 
                  onClick={postNewRide}
                  className="mt-12 w-full py-4 bg-emerald-500 hover:bg-white hover:text-black transition-colors text-lg font-semibold rounded-2xl"
                >
                  PUBLISH THIS RIDE
                </button>
                
                <div className="text-center text-xs text-zinc-500 mt-8">Riders will be able to message you after booking</div>
              </div>
            </div>
          )}

          {/* MY RIDES / TRIPS */}
          {currentPage === 'my-rides' && (
            <div>
              <h1 className="text-4xl font-semibold tracking-tighter mb-8">My Trips</h1>
              
              {currentUser?.role === 'driver' && (
                <div>
                  <div className="uppercase text-xs mb-4 text-zinc-400 px-1">RIDES YOU OFFERED</div>
                  {myRides.length > 0 ? (
                    <div className="space-y-4">
                      {myRides.map(ride => (
                        <div key={ride.id} className="bg-zinc-900 p-6 rounded-3xl flex justify-between items-center group">
                          <div>
                            <div className="font-semibold">{ride.from} — {ride.to}</div>
                            <div className="text-sm text-zinc-400 mt-1">{ride.date} at {ride.time} • {ride.vehicleModel}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-emerald-400 font-medium text-xl">${ride.pricePerSeat}</div>
                            <div className="text-xs text-zinc-400">{ride.seatsAvailable} seats left</div>
                          </div>
                          <div className="flex items-center gap-4 opacity-40 group-hover:opacity-100 transition">
                            <button onClick={() => completeRide(ride.id)} className="px-5 py-2 text-xs border border-emerald-400 text-emerald-400 rounded-2xl">MARK COMPLETE</button>
                            <button onClick={() => deleteRide(ride.id)} className="text-red-400"><Trash2 className="h-4 w-4" /></button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-12 bg-zinc-900 rounded-3xl text-center text-zinc-400">You haven't posted any rides yet.</div>
                  )}
                </div>
              )}

              {currentUser?.role === 'passenger' && (
                <>
                  <div className="uppercase text-xs mb-4 text-zinc-400 px-1">YOUR BOOKINGS</div>
                  {myBookings.length > 0 ? myBookings.map((booking, index) => {
                    const r = rides.find(rr => rr.id === booking.rideId);
                    return (
                      <div key={index} className="border border-zinc-800 bg-zinc-900 rounded-3xl p-6 mb-4">
                        <div className="flex justify-between">
                          <div>
                            <div>{r?.from} → {r?.to}</div>
                            <div className="text-xs mt-2 text-zinc-400">{r?.date} {r?.time}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-xs text-zinc-400">TOTAL PAID</div>
                            <div className="font-mono text-3xl text-white">${booking.totalPrice}</div>
                          </div>
                        </div>
                        
                        <div className="mt-8 flex gap-3">
                          <button onClick={() => cancelBooking(booking.id)} className="text-xs px-6 py-3 border border-red-400 text-red-400 rounded-2xl">Cancel Booking</button>
                          {r?.status === 'completed' && <button onClick={() => {setReviewRide(r); setShowReviewModal(true);}} className="text-xs px-6 py-3 border border-white/60 text-white rounded-2xl">Leave a Review</button>}
                        </div>
                      </div>
                    );
                  }) : <div className="p-20 bg-zinc-900 rounded-3xl text-center">You have no bookings yet.</div>}
                </>
              )}
            </div>
          )}

          {/* PROFILE */}
          {currentPage === 'profile' && (
            <div className="max-w-md mx-auto">
              <div className="flex flex-col items-center">
                <div className="h-28 w-28 rounded-3xl overflow-hidden mb-6 border-4 border-zinc-800 shadow-inner">
                  <img src={currentUser.avatar} alt="" className="object-cover" />
                </div>
                
                <h2 className="text-3xl font-semibold">{currentUser.name}</h2>
                <div className="flex items-center gap-2 text-emerald-400 text-sm mt-1">
                  ★★★★☆ <span className="text-zinc-400 text-xs">({currentUser.rating})</span>
                </div>
                <div className="text-xs bg-zinc-900 px-4 py-1 rounded-3xl mt-4">{currentUser.role.toUpperCase()}</div>
              </div>
              
              <div className="mt-12 bg-zinc-900 rounded-3xl p-8">
                <div className="flex justify-between text-xs text-zinc-400 mb-4">
                  <div>ABOUT YOU</div>
                  <button onClick={() => {setProfileEdit(!profileEdit); setEditedUser({...currentUser});}} className="text-emerald-400">EDIT</button>
                </div>
                
                {profileEdit && editedUser ? (
                  <div>
                    <textarea 
                      value={editedUser.bio} 
                      onChange={(e) => setEditedUser({...editedUser, bio: e.target.value})}
                      className="w-full h-28 bg-zinc-800 p-5 rounded-2xl text-sm" 
                    />
                    <button onClick={() => {setCurrentUser(editedUser); setProfileEdit(false);}} className="mt-4 w-full py-3 bg-white text-black rounded-2xl text-sm">SAVE PROFILE</button>
                  </div>
                ) : (
                  <p className="text-zinc-300 text-[15px] leading-relaxed">{currentUser.bio}</p>
                )}
                
                {currentUser.role === 'driver' && (
                  <div className="mt-10 pt-10 border-t border-zinc-700">
                    <div className="text-xs text-zinc-400 mb-4">YOUR VEHICLE</div>
                    <div className="flex gap-6">
                      <div className="bg-zinc-950 px-5 py-4 rounded-2xl flex-1">
                        <div className="font-medium text-lg">{userVehicle.model}</div>
                        <div className="text-xs text-zinc-400 mt-px">{userVehicle.plate}</div>
                      </div>
                      <div className="text-xs leading-tight pt-1">
                        SEATS<br />
                        <span className="text-4xl font-semibold text-white tabular-nums">{userVehicle.seats}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ADMIN */}
          {currentPage === 'admin' && currentUser?.role === 'admin' && (
            <div>
              <h1 className="font-semibold text-4xl mb-2">Admin Dashboard</h1>
              <p className="text-zinc-400 mb-10">Manage the entire platform</p>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* All Users */}
                <div className="bg-zinc-900 rounded-3xl p-8">
                  <div className="flex items-center justify-between mb-6">
                    <div className="uppercase text-xs font-medium text-amber-400">ALL USERS ({allUsers.length})</div>
                    <button className="text-xs px-4 py-2 border border-amber-400 rounded-2xl">+ ADD USER</button>
                  </div>
                  
                  <div className="space-y-px">
                    {allUsers.map((user, i) => (
                      <div key={i} className="flex justify-between items-center py-4 border-b border-zinc-800 last:border-none">
                        <div className="flex items-center gap-4">
                          <img src={user.avatar} className="h-8 w-8 rounded-2xl" />
                          <div>
                            <div>{user.name}</div>
                            <div className="text-xs text-zinc-500">{user.email}</div>
                          </div>
                        </div>
                        <div className="text-xs uppercase tracking-widest bg-zinc-800 px-4 py-2 rounded-3xl text-center">{user.role}</div>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* All Rides */}
                <div className="bg-zinc-900 rounded-3xl p-8">
                  <div className="uppercase text-xs font-medium text-amber-400 mb-6">LIVE RIDES ({allRidesForAdmin.length})</div>
                  
                  {allRidesForAdmin.map((ride, index) => (
                    <div key={index} className="flex justify-between py-6 border-b border-zinc-800 last:border-0">
                      <div>
                        <div className="font-medium">{ride.from} → {ride.to}</div>
                        <div className="text-xs text-zinc-400 mt-px">{ride.driverName} • {ride.date}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium">${ride.pricePerSeat} × {ride.seatsAvailable}</div>
                        <button onClick={() => deleteRide(ride.id)} className="text-red-400 text-xs mt-3">REMOVE</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* BOOKING MODAL */}
      {showBookingModal && selectedRide && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100]">
          <div className="bg-zinc-900 rounded-3xl w-full max-w-md mx-4 overflow-hidden">
            <div className="p-8">
              <h3 className="font-semibold text-2xl">Confirm your booking</h3>
              <div className="mt-8 text-sm text-zinc-400">TRIP</div>
              <div className="text-xl font-medium mt-px">{selectedRide.from} to {selectedRide.to}</div>
              
              <div className="flex justify-between mt-10">
                <div>
                  <div className="text-xs text-zinc-400">DATE &amp; TIME</div>
                  <div>{selectedRide.date} • {selectedRide.time}</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-zinc-400">DRIVER</div>
                  <div>{selectedRide.driverName}</div>
                </div>
              </div>
              
              <div className="my-8 border border-dashed border-zinc-700"></div>
              
              <div className="flex justify-between items-center">
                <div>
                  <div className="text-xs text-zinc-400">SEATS</div>
                  <div className="flex items-center gap-4 mt-2">
                    <button onClick={() => setBookingSeats(Math.max(1, bookingSeats - 1))} className="h-9 w-9 flex items-center justify-center border border-zinc-700 rounded-xl">-</button>
                    <div className="tabular-nums w-8 text-center text-3xl font-semibold">{bookingSeats}</div>
                    <button onClick={() => setBookingSeats(Math.min(selectedRide.seatsAvailable, bookingSeats + 1))} className="h-9 w-9 flex items-center justify-center border border-zinc-700 rounded-xl">+</button>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="text-xs text-zinc-400">TOTAL DUE</div>
                  <div className="text-5xl font-semibold text-emerald-400">${selectedRide.pricePerSeat * bookingSeats}</div>
                </div>
              </div>
            </div>
            
            <div className="bg-black p-5 flex gap-4">
              <button onClick={() => {setShowBookingModal(false); setSelectedRide(null);}} className="flex-1 py-4 text-sm border border-zinc-700 rounded-2xl">CANCEL</button>
              <button onClick={() => bookRide(selectedRide)} className="flex-1 py-4 text-sm bg-white text-black rounded-2xl font-semibold">CONFIRM BOOKING</button>
            </div>
          </div>
        </div>
      )}

      {/* REVIEW MODAL */}
      {showReviewModal && reviewRide && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-5">
          <div className="bg-zinc-900 w-full max-w-md rounded-3xl p-8">
            <h3 className="font-semibold text-2xl">How was your ride?</h3>
            <div className="mt-2 text-sm text-zinc-400">with {reviewRide.driverName}</div>
            
            <div className="flex gap-2 justify-center my-8">
              {[1,2,3,4,5].map(n => (
                <button key={n} onClick={() => setReviewRating(n)} className={`text-4xl transition ${reviewRating >= n ? 'text-yellow-400' : 'text-zinc-700'}`}>
                  ★
                </button>
              ))}
            </div>
            
            <textarea 
              value={reviewComment} 
              onChange={(e) => setReviewComment(e.target.value)} 
              className="bg-zinc-950 w-full h-24 rounded-2xl p-5 text-sm" 
              placeholder="Write a review (optional)"
            />
            
            <div className="flex gap-x-3 mt-8">
              <button onClick={() => setShowReviewModal(false)} className="flex-1 py-4 text-sm border border-zinc-700 rounded-2xl">CANCEL</button>
              <button onClick={submitReview} className="flex-1 py-4 bg-emerald-500 rounded-2xl text-sm font-medium">SUBMIT REVIEW</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
